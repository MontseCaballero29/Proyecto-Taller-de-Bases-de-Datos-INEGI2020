/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Montse Caballero
 */
public class ConexionMySQL {
    
    private static ConexionMySQL instance = null;
    private Connection conn = null;

    private ConexionMySQL() {
        try {
            String puerto = "3306";
            String nombreBD = "bdinegi2020";
            String usuario = "PROFESORA";
            String password = "12345678a.";

            String URL = "jdbc:mysql://localhost:" + puerto + "/" + nombreBD
                        + "?useSSL=false&serverTimezone=UTC";

            conn = DriverManager.getConnection(URL, usuario, password);

        } catch (SQLException e) {
            System.out.println("❌ Error al conectar a la base de datos:");
            System.out.println("Mensaje: " + e.getMessage());
        }
    }

    public static ConexionMySQL getInstance() {
        if (instance == null) {
            instance = new ConexionMySQL();
        }
        return instance;
    }

    public Connection getConnection() {
        return conn;
    }

    public void closeConnection() {
        try {
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}
