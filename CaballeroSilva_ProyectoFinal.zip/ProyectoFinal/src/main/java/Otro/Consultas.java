/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Otro;

import Conexion.ConexionMySQL;
import java.sql.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;
/**
 *
 * @author Montse Caballero
 */
public class Consultas extends javax.swing.JFrame {

 
     
     private final String[] descripciones = {
        "Cuántas localidades tiene el primer municipio de la entidad 18",
        "Cuántas mujeres viven en el municipio 2 de la entidad 5 (proyectar identidad, idmunicipio y cantidad de mujeres)",
        "Cuáles son los municipios que en su nombre tienen la cadena San Javier (proyectar identidad, idmunicipio y nom_municipio)",
        "Cuántas localidades hay en las entidades 8, 9, 11 (proyectar identidad y cantidad de localidades)",
        "Mostrar las entidades federativas que tienen más de siete millones de habitantes (proyectar identidad y cantidad de habitantes)",
        "Cuál es el municipio que tiene la mayor cantidad de hombres en el país (proyectar identidad, idmunicipio y población de hombres)",
        "Cuántas mujeres había en el país en el 2020",
        "Cuál es el municipio del país con menor cantidad de habitantes hombres (proyectar identidad, idmunicipio y cantidad de hombres)",
        "Cuál es la entidad con menor cantidad de municipios en el país (proyectar identidad y cantidad de municipios)",
        "Cuántos habitantes existen en el país entre 5 y 19 años (proyectar la cantidad de habitantes en este rango de edades)",
        "Cuáles son las entidades federativas que tienen una población entre 15 a 29 años mayor a 5 millones de habitantes",
        "Cuál es el municipio que tiene más adultos mayores (60+ años) en el país",
        "Cuántos derechohabientes del IMSS existen en Oaxaca",
        "Cuáles son las 3 entidades del país con más derechohabientes del ISSSTE",
        "Cantidad de población afrodescendiente en cada entidad federativa del país",
        "Cuántas personas analfabetas de 15 años en adelante existen en Veracruz",
        "Nombre de la entidad y cantidad de municipios que tienen localidades que comiencen con la cadena ATZOMPA",
        "Elimina los registros de la tabla localidades que coincidan con la consulta no. 2"
    };

    private final String[] consultas = {
        // 1
        "SELECT COUNT(*) AS total_localidades " +
        "FROM LOCALIDADES " +
        "WHERE IDENTIDAD = 18 AND IDMUNICIPIO = 1",

        // 2
        "SELECT IDENTIDAD, IDMUNICIPIO, SUM(POBFEM) AS total_mujeres " +
        "FROM LOCALIDADES " +
        "WHERE IDENTIDAD = 5 AND IDMUNICIPIO = 2",

        // 3
        "SELECT IDENTIDAD, IDMUNICIPIO, NOM_MUNICIPIO " +
        "FROM MUNICIPIOS " +
        "WHERE NOM_MUNICIPIO LIKE '%SAN JAVIER%'",

        // 4
        "SELECT IDENTIDAD, COUNT(IDLOCALIDAD) AS cantidad_localidades " +
        "FROM LOCALIDADES " +
        "WHERE IDENTIDAD IN (8, 9, 11) " +
        "GROUP BY IDENTIDAD " +
        "ORDER BY IDENTIDAD",

        // 5
        "SELECT IDENTIDAD, SUM(POBTOT) AS pobtotal " +
        "FROM LOCALIDADES " +
        "GROUP BY IDENTIDAD " +
        "HAVING SUM(POBTOT) > 7000000 " +
        "ORDER BY pobtotal DESC",

        // 6
        "SELECT IDENTIDAD, IDMUNICIPIO, SUM(POBMAS) AS cantidad_hombres " +
        "FROM LOCALIDADES " +
        "GROUP BY IDENTIDAD, IDMUNICIPIO " +
        "ORDER BY cantidad_hombres DESC " +
        "LIMIT 1",

        // 7
        "SELECT SUM(POBFEM) AS total_mujeres_pais " +
        "FROM LOCALIDADES",

        // 8
        "SELECT IDENTIDAD, IDMUNICIPIO, SUM(POBMAS) AS cantidad_hombres " +
        "FROM LOCALIDADES " +
        "GROUP BY IDENTIDAD, IDMUNICIPIO " +
        "ORDER BY cantidad_hombres ASC " +
        "LIMIT 1",

        // 9
        "SELECT IDENTIDAD, COUNT(IDMUNICIPIO) AS cant_municipios " +
        "FROM MUNICIPIOS " +
        "GROUP BY IDENTIDAD " +
        "ORDER BY cant_municipios ASC " +
        "LIMIT 1",

        // 10
        "SELECT SUM(P_5A9 + P_10A14 + P_15A19) AS HABITANTES_5A19 " +
        "FROM EDADES",

        // 11
        "SELECT E.IDENTIDAD, E.NOM_ENTIDAD, " +
        "SUM(ED.P_15A19 + ED.P_20A24 + ED.P_25A29) AS TOTALHAB_15A29 " +
        "FROM ENTIDADES E " +
        "INNER JOIN EDADES ED ON E.IDENTIDAD = ED.ENTIDAD " +
        "GROUP BY E.IDENTIDAD, E.NOM_ENTIDAD " +
        "HAVING TOTALHAB_15A29 > 500000",

        // 12
        "SELECT E.NOM_ENTIDAD AS ENTIDAD, " +
        "M.NOM_MUNICIPIO AS MUNICIPIO, " +
        "SUM(ED.P_60A64 + ED.P_65A69 + ED.P_70A74 + ED.P_75A79 + ED.P_80A84 + ED.P_85YMAS) AS ADULTOS_MAYORES " +
        "FROM EDADES ED " +
        "JOIN ENTIDADES E ON E.IDENTIDAD = ED.ENTIDAD " +
        "JOIN MUNICIPIOS M ON M.IDENTIDAD = ED.ENTIDAD AND M.IDMUNICIPIO = ED.MUN " +
        "GROUP BY E.NOM_ENTIDAD, M.NOM_MUNICIPIO " +
        "ORDER BY ADULTOS_MAYORES DESC " +
        "LIMIT 1",

        // 13
        "SELECT E.NOM_ENTIDAD, SUM(S.PDER_IMSS) AS DERECHOHAB_IMSS " +
        "FROM SALUD S " +
        "JOIN ENTIDADES E ON E.IDENTIDAD = S.ENTIDAD " +
        "WHERE UPPER(E.NOM_ENTIDAD) = 'OAXACA' " +
        "GROUP BY E.NOM_ENTIDAD",

        // 14
        "SELECT E.NOM_ENTIDAD, SUM(S.PDER_ISTE) AS DERECHOHAB_ISSSTE " +
        "FROM SALUD S " +
        "JOIN ENTIDADES E ON E.IDENTIDAD = S.ENTIDAD " +
        "GROUP BY E.NOM_ENTIDAD " +
        "ORDER BY DERECHOHAB_ISSSTE DESC " +
        "LIMIT 3",

        // 15
        "SELECT E.NOM_ENTIDAD AS ENTIDAD, " +
        "SUM(L.POB_AFRO) AS POBLACION_AFRODESCENDIENTE " +
        "FROM LENGUAS L " +
        "JOIN ENTIDADES E ON E.IDENTIDAD = L.ENTIDAD " +
        "GROUP BY E.NOM_ENTIDAD " +
        "ORDER BY POBLACION_AFRODESCENDIENTE DESC",

        // 16
        "SELECT E.NOM_ENTIDAD AS ENTIDAD, " +
        "SUM(A.P15YM_AN) AS ANALFABETAS_15YMAS " +
        "FROM ENTIDADES E " +
        "JOIN MUNICIPIOS M ON M.IDENTIDAD = E.IDENTIDAD " +
        "JOIN ANALFABETISMO A ON A.ENTIDAD = M.IDENTIDAD AND A.MUN = M.IDMUNICIPIO " +
        "WHERE E.NOM_ENTIDAD = 'VERACRUZ DE IGNACIO DE LA LLAVE' " +
        "GROUP BY E.NOM_ENTIDAD",

        // 17
        "SELECT E.NOM_ENTIDAD AS ENTIDAD, " +
        "COUNT(DISTINCT M.IDMUNICIPIO) AS MUNICIPIOS_CON_ATZOMPA " +
        "FROM ENTIDADES E " +
        "JOIN MUNICIPIOS M ON M.IDENTIDAD = E.IDENTIDAD " +
        "JOIN LOCALIDADES L ON L.IDENTIDAD = M.IDENTIDAD AND L.IDMUNICIPIO = M.IDMUNICIPIO " +
        "WHERE L.NOM_LOC LIKE 'ATZOMPA%' " +
        "GROUP BY E.NOM_ENTIDAD " +
        "ORDER BY E.NOM_ENTIDAD",

        // 18 
        "DELETE FROM LOCALIDADES WHERE NOM_LOC LIKE 'ATZOMPA%'"
    };

    private DefaultTableModel modelo;
    
    /**
     * Creates new form Consultas
     */
    public Consultas() {
        initComponents();
         
        modelo = new DefaultTableModel();
        jTableConsultas.setModel(modelo);

        jComboBoxConsultas.addActionListener(e -> seleccionarConsulta());
    }

   private void seleccionarConsulta() {
        int idxCombo = jComboBoxConsultas.getSelectedIndex();
        if (idxCombo <= 0) {  
            jLabel1.setText("");
            jLabel2.setText("");
            modelo.setRowCount(0);
            modelo.setColumnCount(0);
            return;
        }

        int indice = idxCombo - 1;  

        
        jLabel2.setText("<html>" + descripciones[indice] + "</html>");
        jLabel1.setText("<html>" + consultas[indice] + "</html>");

        if (indice == 17) {
         
            ejecutarDelete(indice);
        } else {
          
            ejecutarSelect(indice);
        }
    }

    private void ejecutarSelect(int indice) {
        modelo.setRowCount(0);
        modelo.setColumnCount(0);

        Connection con = ConexionMySQL.getInstance().getConnection();
        if (con == null) {
            JOptionPane.showMessageDialog(this,
                    "No hay conexión con la base de datos.",
                    "Error de conexión",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(consultas[indice])) {

            ResultSetMetaData md = rs.getMetaData();
            int columnas = md.getColumnCount();
       
            for (int i = 1; i <= columnas; i++) {
                modelo.addColumn(md.getColumnLabel(i));
            }
        
            while (rs.next()) {
                Object[] fila = new Object[columnas];
                for (int i = 1; i <= columnas; i++) {
                    fila[i - 1] = rs.getObject(i);
                }
                modelo.addRow(fila);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "ERROR al ejecutar la consulta:\n" + ex.getMessage(),
                    "Error SQL",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void ejecutarDelete(int indice) {
        Connection con = ConexionMySQL.getInstance().getConnection();
        if (con == null) {
            JOptionPane.showMessageDialog(this,
                    "No hay conexión con la base de datos.",
                    "Error de conexión",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Statement st = con.createStatement()) {
            int filas = st.executeUpdate(consultas[indice]);

            JOptionPane.showMessageDialog(this,
                    "DELETE ejecutado.\nFilas afectadas: " + filas,
                    "Operación completada",
                    JOptionPane.INFORMATION_MESSAGE);

            modelo.setRowCount(0);
            modelo.setColumnCount(0);

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "ERROR al ejecutar el DELETE:\n" + ex.getMessage(),
                    "Error SQL",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableConsultas = new javax.swing.JTable();
        jComboBoxConsultas = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        bMenu = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setForeground(new java.awt.Color(255, 204, 204));

        jTableConsultas.setBackground(new java.awt.Color(0, 0, 0));
        jTableConsultas.setForeground(new java.awt.Color(255, 204, 255));
        jTableConsultas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTableConsultas);

        jTabbedPane1.addTab("tab1", jScrollPane1);

        jComboBoxConsultas.setBackground(new java.awt.Color(51, 51, 51));
        jComboBoxConsultas.setForeground(new java.awt.Color(255, 204, 255));
        jComboBoxConsultas.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "...", "Ejercicio 1", "Ejercicio 2", "Ejercicio 3", "Ejercicio 4", "Ejercicio 5", "Ejercicio 6", "Ejercicio 7", "Ejercicio 8", "Ejercicio 9", "Ejercicio 10", "Ejercicio 11", "Ejercicio 12", "Ejercicio 13", "Ejercicio 14", "Ejercicio 15", "Ejercicio 16", "Ejercicio 17", "Ejercicio 18", " " }));
        jComboBoxConsultas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jComboBoxConsultasMouseClicked(evt);
            }
        });

        jLabel1.setForeground(new java.awt.Color(255, 204, 255));

        jLabel2.setForeground(new java.awt.Color(255, 204, 255));
        jLabel2.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));

        bMenu.setBackground(new java.awt.Color(51, 51, 51));
        bMenu.setFont(new java.awt.Font("Yu Gothic UI Semibold", 3, 12)); // NOI18N
        bMenu.setForeground(new java.awt.Color(255, 204, 255));
        bMenu.setText("Menú");
        bMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bMenuMouseClicked(evt);
            }
        });

        jLabel3.setForeground(new java.awt.Color(255, 204, 255));
        jLabel3.setText("Selecciona Ejercicio");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(69, 69, 69)
                        .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 592, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(40, 40, 40)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jComboBoxConsultas, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(bMenu)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGap(57, 57, 57)
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(138, 138, 138)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 485, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 497, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(79, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(bMenu)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel3)
                        .addGap(10, 10, 10)
                        .addComponent(jComboBoxConsultas, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)))
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 368, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBoxConsultasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jComboBoxConsultasMouseClicked
          int indice = jComboBoxConsultas.getSelectedIndex();

    if (indice <= 0 || indice >= 19) return; 

    jLabel2.setText(descripciones[indice - 1]);
    jLabel1.setText(consultas[indice - 1]);

    if (indice == 19) {          
        ejecutarDelete(17);       
    } else {
        ejecutarSelect(indice - 1);
    }
    }//GEN-LAST:event_jComboBoxConsultasMouseClicked

    private void bMenuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bMenuMouseClicked
  Menu m = new Menu();
           m.setVisible(true);
            this.dispose();
    }//GEN-LAST:event_bMenuMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Consultas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Consultas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Consultas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Consultas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Consultas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bMenu;
    private javax.swing.JComboBox<String> jComboBoxConsultas;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTableConsultas;
    // End of variables declaration//GEN-END:variables
}
