/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Main;

import Otro.Menu;

/**
 *
 * @author Montse Caballero
 */
public class Main {
    
      public static void main(String[] args) {

        try {
            javax.swing.UIManager.setLookAndFeel(
                javax.swing.UIManager.getSystemLookAndFeelClassName()
            );
        } catch (Exception e) {
            System.out.println("No se pudo aplicar el Look and Feel");
        }
     java.awt.EventQueue.invokeLater(() -> {
            new Menu().setVisible(true);
        });
    }
}
